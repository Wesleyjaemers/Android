package com.androidatc.lesson_07_android_recyclerview.model

class Place {
    var CountryName: String?=null
    var CityName :String?=null
}

